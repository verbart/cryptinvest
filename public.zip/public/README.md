Код проекта с инструкцией по его сборке здесь - [https://github.com/verbart/cryptinvest]()
